      <!-- Core JavaScript-->
      <script src="<?= base_url("assets/back/vendors/jquery/jquery.min.js") ?>"></script>
      <script src="<?= base_url("assets/back/vendors/popper/popper.min.js") ?>"></script>
      <script src="<?= base_url("assets/back/vendors/bootstrap/js/bootstrap.min.js") ?>"></script>

      <!-- Custom scripts for all pages-->
      <script src="<?= base_url("assets/back/js/sb-admin-2.min.js") ?>"></script>

   </body>
</html>